export const environment = {
  production: true,
  endPoint: "http://localhost:3000/api/posts"
};
