import { Directive } from '@angular/core';

@Directive({
  selector: '[appTimercount]'
})
export class TimercountDirective {

  constructor() { }

}
