import { Directive } from '@angular/core';

@Directive({
  selector: '[appTextpysexam]'
})
export class TextpysexamDirective {

  constructor() { }

}
