import { Directive } from '@angular/core';

@Directive({
  selector: '[appTexthistory]'
})
export class TexthistoryDirective {

  constructor() { }

}
