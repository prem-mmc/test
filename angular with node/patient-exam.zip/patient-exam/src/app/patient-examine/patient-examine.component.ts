import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-patient-examine',
  templateUrl: './patient-examine.component.html',
  styleUrls: ['./patient-examine.component.css']
})
export class PatientExamineComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
